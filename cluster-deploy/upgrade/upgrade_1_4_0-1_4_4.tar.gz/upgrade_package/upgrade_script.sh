#!/bin/bash

set -euo pipefail
################################  请根据实际情况修改以下参数  ################################
# FATE根目录
FATE_ROOT=/data/projects/fate
# FATE FLOW根目录
FATE_FLOW_ROOT=/data/projects/fate/python/fate_flow
# 解压后的更新包路径
PYTHON_PACKAGE_PATH=/tmp/upgrade_python_package.tar.gz
# 数据库账户
DB_USER=root
# 数据库密码
DB_PASS=fate_dev
# 数据库根目录
MYSQL_ROOT=$FATE_ROOT/common/mysql/mysql-8.0.13
# 数据库sock文件路径
MYSQL_SOCKET_PATH=$MYSQL_ROOT/run/mysql.sock
# 请从allinone和ansible中选择一个
DEPLOY_METHOD=allinone
# 如果DEPLOY_METHOD为ansible，请再次确认SUPERVISOR的路径
SUPERVISOR_ROOT=/data/projects/common/supervisord
################################  请根据实际情况修改以上参数  ################################

FATE_PYTHON_ROOT=$FATE_ROOT/python
SCRIPT_PATH=$(dirname $(readlink -f "$0"))

export FATE_ROOT=$FATE_ROOT
export FATE_FLOW_ROOT=$FATE_FLOW_ROOT
export FATE_PYTHON_ROOT=$FATE_PYTHON_ROOT
export SCRIPT_PATH=$SCRIPT_PATH
export PYTHON_PACKAGE_PATH=$PYTHON_PACKAGE_PATH
export DB_USER=$DB_USER
export DB_PASS=$DB_PASS
export DEPLOY_METHOD=$DEPLOY_METHOD
export MYSQL_ROOT=$MYSQL_ROOT
export MYSQL_SOCKET_PATH=$MYSQL_SOCKET_PATH
export CURDATE=`date -d today +"%Y%m%d%H%M%S"`


function basic_check() {
  echo "INFO: Checking if python package path $PYTHON_PACKAGE_PATH exists..."
  if [ ! -f $PYTHON_PACKAGE_PATH ]; then
    echo "ERROR: New python package $PYTHON_PACKAGE_PATH does not exist. Upgrade process aborting.";
    exit 1;
  else
    echo "INFO: Done."
  fi
}


function check_deploy_method() {
  echo "INFO: Cheching if deploy method is valid..."
  if [ "$DEPLOY_METHOD" != "ansible" ] && [ "$DEPLOY_METHOD" != "allinone" ]; then
    echo "ERROR: please choose deploy method from one of 'allinone' and 'ansible'. Upgrade process aborting.";
    exit 1;
  else
    echo "INFO: Deploy method is $DEPLOY_METHOD";
  fi

  case $DEPLOY_METHOD in
    "ansible")
      if [ ! -f $SUPERVISOR_ROOT/service.sh ]; then
        echo "ERROR: SUPERVISOR execute file $SUPERVISOR_ROOT/service.sh not exists. Upgrade process aborting.";
        exit 1;
      fi;;
  esac
}


function check_fate_root() {
  echo "INFO: Checking if fate root $FATE_ROOT exists..."
  if [ ! -d $FATE_ROOT ]; then
    echo "ERROR: Fate root $FATE_ROOT does not exist. Upgrade process aborting.";
    exit 1;
  else
    echo "INFO: Done."
  fi
}


function check_flow_root() {
  echo "INFO: Checking if fate flow root $FATE_FLOW_ROOT exists..."
  if [ ! -d $FATE_FLOW_ROOT ]; then
    echo "ERROR: Fate flow root $FATE_FLOW_ROOT does not exist. Upgrade process aborting.";
    exit 1;
  else
    echo "INFO: Done."
  fi
}


function check_mysql_conn() {
  echo "INFO: Checking mysql connection.."

  echo "INFO: Checking if mysql root $MYSQL_ROOT exists..."
  if [ ! -d $MYSQL_ROOT ]; then
    echo "ERROR: Mysql root $FATE_ROOT does not exist. Upgrade process aborting.";
    exit 1;
  else
    echo "INFO: Done."
  fi

  $MYSQL_ROOT/bin/mysql -u$DB_USER -p$DB_PASS -S $MYSQL_SOCKET_PATH -e "select 'x';"
  if [ $? -ne 0 ]; then
    echo "ERROR: Mysql connect failed. Upgrade process aborting.";
    exit 1;
  else
    echo "INFO: Done."
  fi

  echo "INFO: Checking progress finished."
}


function stop() {
  echo "INFO: Stoping fate flow server..."
  case $DEPLOY_METHOD in
    "allinone")
      sh $FATE_FLOW_ROOT/service.sh stop;;
    "ansible")
      sh $SUPERVISOR_ROOT/service.sh stop fate-fateflow;;
  esac
}


function start() {
  echo "INFO: Starting fate flow server..."
  case $DEPLOY_METHOD in
    "allinone")
      sh $FATE_FLOW_ROOT/service.sh start;;
    "ansible")
      sh $SUPERVISOR_ROOT/service.sh start fate-fateflow;;
  esac
}


function backup_python() {
  echo "INFO: Backup for old python directory"
  PYTHON_BACKUP_PATH=$FATE_ROOT/python_$CURDATE
  export PYTHON_BACKUP_PATH=$PYTHON_BACKUP_PATH
  mv $FATE_PYTHON_ROOT $PYTHON_BACKUP_PATH
  echo "INFO: Backup FATE PYTHON DIR successfully. Old python directory currently located at $PYTHON_BACKUP_PATH"
}


function backup_flow() {
  echo "INFO: Backup for old flow directory"
  FLOW_BACKUP_PATH=$FATE_ROOT/python/fate_flow_$CURDATE
  export FLOW_BACKUP_PATH=$FLOW_BACKUP_PATH
  mv $FATE_FLOW_ROOT $FLOW_BACKUP_PATH
  echo "INFO: Backup FATE FLOW DIR successfully. Old flow directory currently located at $FLOW_BACKUP_PATH"
}


function unpack_package() {
  echo "INFO: Unpacking new python package..."
  if [ ! -f $SCRIPT_PATH/python ]; then
    tar zxf $PYTHON_PACKAGE_PATH -C $SCRIPT_PATH;
    echo "INFO: Python package unpacked successfully.";
  else
    echo "INFO: Upgrade package has been unpacked already.";
  fi
}


function replace_python_dir() {
  echo "INFO: Moving new python package into fate root directory..."
  mv $SCRIPT_PATH/python $FATE_ROOT
  echo "INFO: Moving new python package into fate root directory successfully."
}


function replace_flow_dir() {
  echo "INFO: Moving new flow package into fate python root directory..."
  mv $SCRIPT_PATH/python/fate_flow $FATE_PYTHON_ROOT/
  echo "INFO: Moving new flow package into fate python root directory successfully."
}


function replace_conf() {
  echo "INFO: Replacing configurations..."
  mv $FATE_PYTHON_ROOT/arch/conf $FATE_PYTHON_ROOT/arch/conf_$CURDATE
  cp -r $PYTHON_BACKUP_PATH/arch/conf $FATE_PYTHON_ROOT/arch/
  echo "INFO: Configurations replaced successfully."
}


function execute_sql_upgrade() {
  echo "INFO: Upgrading database..."
  $MYSQL_ROOT/bin/mysql -u$DB_USER -p$DB_PASS -S $MYSQL_SOCKET_PATH < $FATE_PYTHON_ROOT/fate_flow/upgrade/1_4_0-1_4_1/upgrade_fate_flow_db.sql
  $MYSQL_ROOT/bin/mysql -u$DB_USER -p$DB_PASS -S $MYSQL_SOCKET_PATH < $FATE_PYTHON_ROOT/fate_flow/upgrade/1_4_1-1_4_2/upgrade_fate_flow_db.sql
  echo "INFO: Upgrade database finished."
}


function restore_files() {
  echo "INFO: Restoring model_local_cache/jobs/logs files..."
  cp -r $PYTHON_BACKUP_PATH/model_local_cache/ $FATE_PYTHON_ROOT/
  cp -r $PYTHON_BACKUP_PATH/jobs/ $FATE_PYTHON_ROOT/
  cp -r $PYTHON_BACKUP_PATH/logs/ $FATE_PYTHON_ROOT/
  echo "INFO: Model_local_cache/jobs/logs files restored successfully."
}


function move_invisible_file() {
  mkdir -p $FATE_ROOT/invisible_files
  mv $FATE_PYTHON_ROOT/arch/transfer_variables/auth_conf/federatedml/._*.json $FATE_ROOT/invisible_files
}


function install_dependency() {
  echo "INFO: Installing python dependency..."
  source $FATE_ROOT/init_env.sh
  pip install $SCRIPT_PATH/requests_toolbelt-0.9.1-py2.py3-none-any.whl
  echo "INFO: Dependency has been installed successfully."
}


function upgrade_mysql() {
  echo "INFO: Upgrading mysql process start..."
  # check
  basic_check
  check_mysql_conn
  # unpack
  unpack_package
  # upgrade
  execute_sql_upgrade
  echo "INFO: Upgrading mysql process finished."
}


function upgrade_fate_python() {
  echo "INFO: Upgrading fate python process start..."
  # check
  basic_check
  check_deploy_method
  check_fate_root
  # unpack
  unpack_package
  # stop service
  stop
  # backup
  backup_python
  # upgrade
  replace_python_dir
  replace_conf
  restore_files
  move_invisible_file
  install_dependency
  # start service
  start
  echo "INFO: Upgrading fate python process finished."
}


function upgrade_fate_flow() {
  echo "INFO: Upgrading fate flow process start..."
  # check
  basic_check
  check_flow_root
  # unpack
  unpack_package
  # stop service
  stop  
  # backup
  backup_flow
  # upgrade
  replace_flow_dir
  # start service
  start
  echo "INFO: Upgrading fate flow process finished."
}


case "$1" in
    fatepython)
        upgrade_fate_python
        ;;
    fateflow)
        upgrade_fate_flow
        ;;
    mysql)
        upgrade_mysql
        ;;
    all)
        upgrade_fate_python
        upgrade_mysql
        ;;
    *)
        echo "usage: $0 {fatepython|fateflow|mysql|all}"
        exit -1
esac
